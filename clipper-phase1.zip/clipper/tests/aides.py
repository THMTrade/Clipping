"""Outils de test : transcription synthétique au format Deepgram, faux client Claude."""
import json
from types import SimpleNamespace

from clipper.transcript import Mot


def mots_synthetiques(nb_phrases=200, mots_par_phrase=12, duree_mot=0.4, pause=0.05, phrases_par_locuteur=10):
    """Phrases de ~5,4 s ; le locuteur alterne tous les `phrases_par_locuteur`."""
    mots, t = [], 0.0
    for p in range(nb_phrases):
        loc = (p // phrases_par_locuteur) % 2
        for k in range(mots_par_phrase):
            fin = k == mots_par_phrase - 1
            mots.append(Mot(f"mot{p}_{k}" + ("." if fin else ""), t, t + duree_mot, loc))
            t += duree_mot + pause
    return mots


def ecrire_deepgram(chemin, mots):
    mots_json = [{"word": m.texte.rstrip("."), "punctuated_word": m.texte, "start": m.debut,
                  "end": m.fin, "speaker": m.locuteur} for m in mots]
    chemin.write_text(json.dumps({"metadata": {"duration": mots[-1].fin},
                                  "results": {"channels": [{"alternatives": [{"words": mots_json}]}]}}),
                      encoding="utf-8")


class FauxClient:
    """Imite client.messages.create ; rend les réponses dans l'ordre et garde les appels."""

    def __init__(self, *reponses, entree=1000, sortie=200):
        self.reponses, self.appels = list(reponses), []
        self.entree, self.sortie = entree, sortie
        self.messages = self

    def create(self, **kw):
        kw["messages"] = list(kw["messages"])
        self.appels.append(kw)
        texte = self.reponses.pop(0)
        return SimpleNamespace(content=[SimpleNamespace(type="text", text=texte)],
                               usage=SimpleNamespace(input_tokens=self.entree, output_tokens=self.sortie),
                               stop_reason="end_turn")


def reponse(*candidats):
    """Fabrique une réponse JSON de Claude à partir de tuples (debut, fin, note)."""
    return json.dumps({"candidats": [
        {"debut_phrase": d, "fin_phrase": f, "sujet": f"Sujet {d}-{f}", "note": n, "raison": "ok"}
        for d, f, n in candidats]})
