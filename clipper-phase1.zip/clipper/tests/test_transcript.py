from clipper.transcript import Mot, decouper_phrases, mots_depuis_deepgram, timecode, formater_ligne
from tests.aides import mots_synthetiques, ecrire_deepgram
import json
import pytest


def test_phrases_coupees_sur_ponctuation_et_numerotees():
    phrases = decouper_phrases(mots_synthetiques(nb_phrases=5))
    assert [p.id for p in phrases] == [0, 1, 2, 3, 4]
    assert all(len(p.texte.split()) == 12 for p in phrases)


def test_coupe_au_changement_de_locuteur_sans_ponctuation():
    mots = [Mot("a", 0, 1, 0), Mot("b", 1, 2, 0), Mot("c", 2, 3, 1), Mot("d", 3, 4, 1)]
    phrases = decouper_phrases(mots)
    assert [(p.texte, p.locuteur) for p in phrases] == [("a b", 0), ("c d", 1)]


def test_coupe_forcee_apres_max_mots():
    mots = [Mot(f"m{i}", i, i + 1, 0) for i in range(25)]
    assert [len(p.texte.split()) for p in decouper_phrases(mots, max_mots=10)] == [10, 10, 5]


def test_ponctuation_suivie_de_guillemet_fermant():
    mots = [Mot("fin.»", 0, 1, 0), Mot("suite", 1, 2, 0)]
    assert len(decouper_phrases(mots)) == 2


def test_lecture_deepgram(tmp_path):
    f = tmp_path / "t.json"
    ecrire_deepgram(f, mots_synthetiques(nb_phrases=2))
    mots = mots_depuis_deepgram(json.loads(f.read_text()))
    assert len(mots) == 24 and mots[0].texte == "mot0_0"


def test_deepgram_vide_ou_inattendu():
    with pytest.raises(ValueError):
        mots_depuis_deepgram({})
    with pytest.raises(ValueError):
        mots_depuis_deepgram({"results": {"channels": [{"alternatives": [{"words": []}]}]}})


def test_timecode_et_ligne():
    assert timecode(3725) == "1:02:05"
    p = decouper_phrases([Mot("Bonjour.", 61.4, 62, 1)])[0]
    assert formater_ligne(p) == "#0 [0:01:01] L1: Bonjour."
