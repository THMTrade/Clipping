from clipper import db, ingest, runner
from clipper.ingest import normaliser_url

CFG = {"ingestion": {"duree_min_s": 600}}


def faux_resolveur(videos):
    return lambda url: videos


def test_ajouter_est_idempotent_et_ignore_les_courtes(tmp_path):
    conn = db.connecter(tmp_path / "t.db")
    vids = [{"id": "a", "titre": "A", "duree_s": 3600}, {"id": "b", "titre": "B", "duree_s": 60},
            {"id": "c", "titre": "C", "duree_s": None}]
    r1 = ingest.ajouter_url(conn, CFG, "u", faux_resolveur(vids))
    r2 = ingest.ajouter_url(conn, CFG, "u", faux_resolveur(vids))
    assert r1 == {"nouvelles": 2, "connues": 0, "ignorees": 1}
    assert r2 == {"nouvelles": 0, "connues": 2, "ignorees": 1}
    assert conn.execute("SELECT COUNT(*) FROM videos").fetchone()[0] == 2


def test_url_de_chaine_nue_vise_l_onglet_videos():
    assert normaliser_url("https://www.youtube.com/@nom") == "https://www.youtube.com/@nom/videos"
    assert normaliser_url("https://www.youtube.com/@nom/videos") == "https://www.youtube.com/@nom/videos"
    assert normaliser_url("https://www.youtube.com/watch?v=abc") == "https://www.youtube.com/watch?v=abc"


def test_une_video_en_echec_ne_bloque_pas_les_autres_et_est_reessayee(tmp_path, monkeypatch):
    conn = db.connecter(tmp_path / "t.db")
    for vid in ("a", "b"):
        db.ajouter_video(conn, vid, "u", vid, 3600)
    appels, panne = [], {"a": True}

    def telecharger(conn, cfg, vid):
        appels.append(vid)
        if panne.get(vid):
            raise RuntimeError("réseau coupé")

    ok = lambda conn, cfg, vid: None
    monkeypatch.setattr(runner, "ETAPES", [("ingestion", telecharger), ("transcription", ok), ("selection", ok)])
    assert runner.lancer(conn, {}) == {"ok": 1, "echec": 1}
    assert db.video(conn, "a")["ingestion"] == "echec" and "réseau coupé" in db.video(conn, "a")["erreur"]
    assert db.video(conn, "b")["selection"] == "ok"

    panne.clear()
    appels.clear()
    assert runner.lancer(conn, {}) == {"ok": 1, "echec": 0}
    assert appels == ["a"]                       # b n'est pas retraitée
    assert db.video(conn, "a")["erreur"] is None


def test_etape_deja_ok_n_est_jamais_refaite(tmp_path, monkeypatch):
    conn = db.connecter(tmp_path / "t.db")
    db.ajouter_video(conn, "a", "u", "a", 3600)
    db.maj_video(conn, "a", ingestion="ok", transcription="ok")
    appels = []
    monkeypatch.setattr(runner, "ETAPES", [("ingestion", lambda *a: appels.append("i")),
                                           ("transcription", lambda *a: appels.append("t")),
                                           ("selection", lambda *a: appels.append("s"))])
    runner.lancer(conn, {})
    assert appels == ["s"]
