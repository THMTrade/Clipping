import json
import pytest
from clipper import db, select
from clipper.select import (ClipCandidat, chevauchement, decouper_blocs, dedoublonner, extraire_json,
                            parser_reponse, valider_candidat)
from clipper.transcript import decouper_phrases
from tests.aides import FauxClient, ecrire_deepgram, mots_synthetiques, reponse

CFG = {
    "dossiers": {"donnees": "data", "prompts": "prompts", "logs": "logs"},
    "transcription": {"phrase_max_mots": 80},
    "selection": {"modele": "m", "clips_min": 2, "clips_max": 3, "duree_min_s": 120, "duree_max_s": 300,
                  "chevauchement_max": 0.2, "bloc_max_caracteres": 10**9, "bloc_recouvrement_caracteres": 0,
                  "max_tokens_sortie": 1000},
    "tarifs": {"claude": {"m": {"entree": 3.0, "sortie": 15.0}}},
}


def clip(d, f, note=80):
    return ClipCandidat(0, 0, d, f, "s", note, "r")


# --- parsing de la sortie de Claude

def test_json_avec_balises_et_texte_autour():
    texte = "Voici :\n```json\n" + reponse((1, 30, 80)) + "\n```\nBonne chance"
    valides, erreurs = parser_reponse(texte)
    assert len(valides) == 1 and valides[0]["debut_phrase"] == 1 and not erreurs


def test_un_candidat_invalide_n_invalide_pas_les_autres():
    texte = json.dumps({"candidats": [
        {"debut_phrase": 1, "fin_phrase": 30, "sujet": "ok", "note": 80},
        {"debut_phrase": 40, "fin_phrase": 10, "sujet": "inversé", "note": 80},
        {"debut_phrase": 1, "fin_phrase": 30, "sujet": "x", "note": 150},
        {"debut_phrase": 1, "fin_phrase": 30, "note": 50},
        "pas un objet",
    ]})
    valides, erreurs = parser_reponse(texte)
    assert len(valides) == 1 and len(erreurs) == 4


def test_nombres_tolerants_mais_pas_les_booleens():
    c = valider_candidat({"debut_phrase": "5", "fin_phrase": 9.0, "sujet": "s", "note": "87"})
    assert (c["debut_phrase"], c["fin_phrase"], c["note"], c["raison"]) == (5, 9, 87, "")
    with pytest.raises(ValueError):
        valider_candidat({"debut_phrase": True, "fin_phrase": 9, "sujet": "s", "note": 1})
    with pytest.raises(ValueError):
        valider_candidat({"debut_phrase": 1.5, "fin_phrase": 9, "sujet": "s", "note": 1})


@pytest.mark.parametrize("texte", ["rien du tout", "{cassé", '{"autre": 1}', '{"candidats": "non"}'])
def test_reponses_inexploitables(texte):
    with pytest.raises(ValueError):
        parser_reponse(texte)


# --- chevauchement et doublons

def test_chevauchement_rapporte_au_plus_court():
    assert chevauchement(clip(0, 100), clip(50, 250)) == 0.5
    assert chevauchement(clip(0, 100), clip(200, 300)) == 0.0
    assert chevauchement(clip(0, 300), clip(100, 150)) == 1.0  # le petit est inclus


def test_dedoublonner_garde_le_mieux_note_et_respecte_le_maximum():
    cands = [clip(0, 200, 70), clip(10, 210, 90), clip(300, 500, 60), clip(600, 800, 50)]
    gardes = dedoublonner(cands, 0.2, 2)
    assert [(c.debut_s, c.note) for c in gardes] == [(10, 90), (300, 60)]


def test_seuil_de_chevauchement_exactement_20_pour_cent_est_refuse():
    assert len(dedoublonner([clip(0, 100, 90), clip(80, 180, 80)], 0.2, 5)) == 1   # 20 %
    assert len(dedoublonner([clip(0, 100, 90), clip(81, 181, 80)], 0.2, 5)) == 2   # 19 %


# --- blocs

def test_blocs_couvrent_tout_se_recouvrent_et_progressent():
    phrases = decouper_phrases(mots_synthetiques(nb_phrases=100))
    blocs = decouper_blocs(phrases, max_car=2000, recouvrement=500)
    assert blocs[0][0] == 0 and blocs[-1][1] == 100
    for (a1, b1), (a2, b2) in zip(blocs, blocs[1:]):
        assert a2 < b1 and a2 > a1      # recouvrement ET progression
    assert len(blocs) > 1


def test_bloc_unique_si_ca_tient():
    phrases = decouper_phrases(mots_synthetiques(nb_phrases=10))
    assert decouper_blocs(phrases, 10**9, 1000) == [(0, 10)]


def test_une_phrase_plus_grosse_que_le_bloc_ne_bloque_pas():
    phrases = decouper_phrases(mots_synthetiques(nb_phrases=3))
    assert decouper_blocs(phrases, max_car=5, recouvrement=2)[-1][1] == 3


# --- sélection complète avec faux client

def test_selection_convertit_phrases_en_secondes_et_ignore_les_ids_inconnus():
    phrases = decouper_phrases(mots_synthetiques(nb_phrases=100))
    client = FauxClient(reponse((10, 50, 90), (5000, 5010, 99), (60, 95, 70)))
    usages = []
    clips = select.selectionner(phrases, {"titre": "T"}, CFG, client, usages)
    assert [(c.phrase_debut, c.phrase_fin) for c in clips] == [(10, 50), (60, 95)]
    assert clips[0].debut_s == phrases[10].debut and clips[0].fin_s == phrases[50].fin
    assert len(usages) == 1


def test_relance_si_json_casse_et_les_deux_appels_sont_comptes():
    phrases = decouper_phrases(mots_synthetiques(nb_phrases=100))
    client = FauxClient("n'importe quoi", reponse((10, 50, 90)))
    usages = []
    assert len(select.selectionner(phrases, {}, CFG, client, usages)) == 1
    assert len(usages) == 2 and len(client.appels[1]["messages"]) == 3


def test_echec_definitif_apres_une_relance():
    phrases = decouper_phrases(mots_synthetiques(nb_phrases=100))
    with pytest.raises(ValueError):
        select.selectionner(phrases, {}, CFG, FauxClient("non", "toujours non"), [])


def test_prompt_rempli_sans_placeholder_restant():
    p = select.remplir_prompt(select.charger_prompt({"dossiers": {"prompts": "prompts"}}, "selection"), CFG, 5, 15)
    assert "{{" not in p and "2 minutes" in p and "20 %" in p


def test_cout_claude():
    assert select.cout_claude(CFG, "m", 1_000_000, 100_000) == pytest.approx(4.5)


# --- étape complète avec base SQLite

def _preparer(tmp_path):
    cfg = json.loads(json.dumps(CFG))
    cfg["dossiers"] = {"donnees": str(tmp_path), "prompts": "prompts", "logs": str(tmp_path / "logs")}
    conn = db.connecter(tmp_path / "t.db")
    db.ajouter_video(conn, "v1", "https://x", "Titre", 1100)
    ecrire_deepgram(tmp_path / "v1.json", mots_synthetiques(nb_phrases=200))
    conn.execute("INSERT INTO transcripts (video_id, chemin_json) VALUES ('v1', ?)", (str(tmp_path / "v1.json"),))
    conn.commit()
    return cfg, conn


def test_selectionner_video_ecrit_clips_et_cout(tmp_path):
    cfg, conn = _preparer(tmp_path)
    select.selectionner_video(conn, cfg, "v1", FauxClient(reponse((10, 50, 90), (80, 130, 75))))
    assert conn.execute("SELECT COUNT(*) FROM clips").fetchone()[0] == 2
    cout = conn.execute("SELECT SUM(cout_usd) FROM cout_api").fetchone()[0]
    assert cout == pytest.approx((1000 * 3 + 200 * 15) / 1e6)


def test_relancer_la_selection_ne_cree_pas_de_doublons(tmp_path):
    cfg, conn = _preparer(tmp_path)
    for _ in range(2):
        select.selectionner_video(conn, cfg, "v1", FauxClient(reponse((10, 50, 90), (80, 130, 75))))
    assert conn.execute("SELECT COUNT(*) FROM clips").fetchone()[0] == 2


def test_cout_compte_meme_si_la_selection_echoue(tmp_path):
    cfg, conn = _preparer(tmp_path)
    with pytest.raises(ValueError):
        select.selectionner_video(conn, cfg, "v1", FauxClient("non", "non"))
    assert conn.execute("SELECT COUNT(*) FROM cout_api").fetchone()[0] == 2
    assert conn.execute("SELECT COUNT(*) FROM clips").fetchone()[0] == 0
