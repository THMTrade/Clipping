# Clipper

## But
Transformer des vidéos YouTube longues (podcasts, interviews, formations — dont j'ai les droits) en clips horizontaux de 2 à 5 min, les faire valider en un clic dans une interface locale, puis les publier en privé avec date programmée sur une chaîne YouTube de clips.

## Stack
Python ≥ 3.10, SQLite, FastAPI + HTML simple (phase 2), tout en local.
yt-dlp (téléchargement) · Deepgram Nova-3 (transcription au mot + locuteurs, via httpx) · API Anthropic (sélection, titres) · ffmpeg (audio, découpe) · YouTube Data API v3 OAuth (phase 3) · OpenCV headless + Pillow (miniatures, phase 2) · pytest.
Pas de Pydantic : la sortie de Claude est validée à la main dans `select.py` (tolérant candidat par candidat).
Clés dans `.env`, réglages dans `config.yaml`, prompts dans `prompts/*.md`.

## Commandes
```
pip install -e ".[dev]"        # installation
clipper add URL                # vidéo, playlist ou chaîne ; n'enregistre que des métadonnées
clipper run [--video ID] [--limite N]   # ingestion → transcription → sélection (reprend après crash)
clipper status [ID]            # tableau + coûts ; avec ID : liste des candidats
clipper review | publish | stats        # phases 2, 3, 4 (pas encore implémentées)
pytest                         # tests
```

## Architecture
`clipper/` : `cli.py` (commandes) · `runner.py` (étapes par vidéo, échec isolé) · `db.py` (schéma SQLite) · `ingest.py` · `transcribe.py` · `transcript.py` (mots → phrases numérotées) · `select.py` · `config.py`.
Données dans `data/` (vidéos, transcripts, base `clipper.db`), logs dans `logs/`. Rien de tout cela n'est versionné.

## Conventions
- Code et commentaires en français ; logs et messages utilisateur en français.
- Chaque étape d'une vidéo a un statut en base (`a_faire` / `ok` / `echec`). Une étape `ok` n'est jamais refaite. Une vidéo en échec ne bloque pas les autres et est réessayée au `run` suivant.
- Cache avant tout appel payant (transcription : `data/transcripts/ID.deepgram.json`, écriture atomique).
- Tout appel payant enregistre son coût dans `cout_api`, même si l'étape échoue ensuite.
- Claude choisit des **numéros de phrases** (pas des secondes) : début/fin tombent sur une frontière de phrase. Les secondes sont dérivées et stockées dans `clips`.
- Imports lourds (`anthropic`, `yt_dlp`, `httpx`) faits dans les fonctions : les tests n'en ont pas besoin.
- Aucun appel réseau dans les tests : faux client Claude dans `tests/aides.py`.
- Rien n'est jamais publié en public directement.
- Pas de dépendance sans raison. Tarifs de `config.yaml` à vérifier.

## État
- [x] Phase 1 : ingestion, transcription, sélection — code et 32 tests écrits ; **pas encore lancée sur une vraie vidéo** (en attente du retour de l'utilisateur).
- [ ] Phase 2 : bornes, découpe, miniatures, revue web
- [ ] Phase 3 : publication, quota (6 uploads/jour max)
- [ ] Phase 4 : suivi à J+2 / J+7, export CSV

## Limites connues
- Moteur WhisperX : non implémenté (`transcription.moteur: whisperx` lève une erreur claire).
- Durée 2–5 min : signalée par `status ID` en phase 1, rejet expliqué en phase 2 (`bounds.py`).
