"""Sélection des clips candidats par Claude.

Claude reçoit la transcription en phrases numérotées et rend des numéros de phrases :
début et fin tombent donc toujours sur une frontière de phrase.
Transcription trop longue : blocs qui se recouvrent, puis fusion et dédoublonnage.
"""
import json
import logging
import math
from dataclasses import dataclass
from pathlib import Path

from . import config, db
from .transcript import decouper_phrases, formater_ligne, mots_depuis_deepgram, timecode

log = logging.getLogger("clipper")


@dataclass
class Utilisation:
    """Tokens consommés par un appel à l'API."""
    entree: int
    sortie: int


@dataclass
class ClipCandidat:
    phrase_debut: int
    phrase_fin: int
    debut_s: float
    fin_s: float
    sujet: str
    note: int
    raison: str

    @property
    def duree_s(self) -> float:
        return self.fin_s - self.debut_s


# ---------------------------------------------------------------- lecture de la sortie de Claude

def extraire_json(texte: str):
    """Isole l'objet JSON d'une réponse, même entourée de texte ou de balises ```."""
    debut, fin = texte.find("{"), texte.rfind("}")
    if debut == -1 or fin <= debut:
        raise ValueError("aucun objet JSON trouvé dans la réponse")
    try:
        return json.loads(texte[debut:fin + 1])
    except json.JSONDecodeError as e:
        raise ValueError(f"JSON invalide : {e}") from e


def _entier(valeur, nom):
    """Accepte 87, 87.0 et "87" ; refuse le reste (dont les booléens)."""
    if isinstance(valeur, bool):
        raise ValueError(f"{nom} doit être un nombre")
    try:
        f = float(valeur)
    except (TypeError, ValueError):
        raise ValueError(f"{nom} doit être un nombre") from None
    if f != int(f):
        raise ValueError(f"{nom} doit être un entier")
    return int(f)


def valider_candidat(brut) -> dict:
    """Vérifie un candidat ; lève ValueError si un champ manque ou est incohérent."""
    if not isinstance(brut, dict):
        raise ValueError("candidat qui n'est pas un objet")
    for cle in ("debut_phrase", "fin_phrase", "sujet", "note"):
        if cle not in brut:
            raise ValueError(f"champ « {cle} » manquant")
    candidat = {
        "debut_phrase": _entier(brut["debut_phrase"], "debut_phrase"),
        "fin_phrase": _entier(brut["fin_phrase"], "fin_phrase"),
        "note": _entier(brut["note"], "note"),
        "sujet": str(brut["sujet"]).strip(),
        "raison": str(brut.get("raison", "")).strip(),
    }
    if not 0 <= candidat["note"] <= 100:
        raise ValueError("note hors de 0-100")
    if candidat["fin_phrase"] < candidat["debut_phrase"]:
        raise ValueError("fin_phrase avant debut_phrase")
    if not candidat["sujet"]:
        raise ValueError("sujet vide")
    return candidat


def parser_reponse(texte: str):
    """Renvoie (candidats valides, erreurs). Un candidat invalide n'invalide pas les autres."""
    donnees = extraire_json(texte)
    liste = donnees.get("candidats") if isinstance(donnees, dict) else None
    if not isinstance(liste, list):
        raise ValueError("clé « candidats » absente ou qui n'est pas une liste")
    valides, erreurs = [], []
    for i, brut in enumerate(liste, 1):
        try:
            valides.append(valider_candidat(brut))
        except ValueError as e:
            erreurs.append(f"candidat {i} : {e}")
    return valides, erreurs


# ---------------------------------------------------------------- découpage, fusion

def decouper_blocs(phrases: list, max_car: int, recouvrement: int) -> list:
    """Blocs (début, fin exclu) d'au plus max_car caractères, qui se recouvrent."""
    tailles = [len(formater_ligne(p)) + 1 for p in phrases]
    n, blocs, debut = len(phrases), [], 0
    while debut < n:
        total, fin = 0, debut
        while fin < n and (total + tailles[fin] <= max_car or fin == debut):
            total += tailles[fin]
            fin += 1
        blocs.append((debut, fin))
        if fin >= n:
            break
        # le bloc suivant repart en arrière pour recouvrir la fin de celui-ci
        k, retour = fin, 0
        while k > debut + 1 and retour < recouvrement:
            k -= 1
            retour += tailles[k]
        debut = k
    return blocs


def chevauchement(a, b) -> float:
    """Part commune, rapportée au plus court des deux clips (0 à 1)."""
    commun = max(0.0, min(a.fin_s, b.fin_s) - max(a.debut_s, b.debut_s))
    court = min(a.duree_s, b.duree_s)
    return commun / court if court > 0 else 1.0


def dedoublonner(candidats: list, chevauchement_max: float, maximum: int) -> list:
    """Garde les mieux notés ; écarte tout candidat qui en recouvre un déjà gardé."""
    gardes = []
    for c in sorted(candidats, key=lambda c: (-c.note, c.debut_s)):
        if any(chevauchement(c, g) >= chevauchement_max for g in gardes):
            log.info("Candidat écarté (chevauchement) : %s", c.sujet)
            continue
        gardes.append(c)
        if len(gardes) == maximum:
            break
    return sorted(gardes, key=lambda c: c.debut_s)


def vers_candidat_clip(brut: dict, par_id: dict, ids_bloc: range):
    """Convertit des numéros de phrases en secondes ; None si un numéro est inconnu."""
    d, f = brut["debut_phrase"], brut["fin_phrase"]
    if d not in par_id or f not in par_id or d not in ids_bloc or f not in ids_bloc:
        log.warning("Candidat ignoré : phrases #%s-#%s absentes du bloc envoyé", d, f)
        return None
    return ClipCandidat(d, f, par_id[d].debut, par_id[f].fin, brut["sujet"], brut["note"], brut["raison"])


# ---------------------------------------------------------------- appel à Claude

def creer_client():
    import anthropic  # import tardif : inutile pour les tests
    return anthropic.Anthropic(api_key=config.cle_api("ANTHROPIC_API_KEY"), max_retries=3)


def cout_claude(cfg: dict, modele: str, entree: int, sortie: int) -> float:
    tarif = cfg.get("tarifs", {}).get("claude", {}).get(modele)
    if not tarif:
        log.warning("Tarif inconnu pour %s dans config.yaml : coût compté à 0", modele)
        return 0.0
    return (entree * tarif["entree"] + sortie * tarif["sortie"]) / 1_000_000


def charger_prompt(cfg: dict, nom: str) -> str:
    return (config.dossier(cfg, "prompts") / f"{nom}.md").read_text(encoding="utf-8")


def remplir_prompt(gabarit: str, cfg: dict, clips_min: int, clips_max: int) -> str:
    sel = cfg["selection"]
    valeurs = {
        "{{CLIPS_MIN}}": str(clips_min),
        "{{CLIPS_MAX}}": str(clips_max),
        "{{DUREE_MIN}}": f"{sel['duree_min_s'] / 60:g} minutes",
        "{{DUREE_MAX}}": f"{sel['duree_max_s'] / 60:g} minutes",
        "{{CHEVAUCHEMENT}}": f"{sel['chevauchement_max'] * 100:g} %",
    }
    for cle, valeur in valeurs.items():
        gabarit = gabarit.replace(cle, valeur)
    return gabarit


def construire_message(meta: dict, phrases: list, num_bloc: int, nb_blocs: int) -> str:
    entete = [f"Vidéo : {meta.get('titre') or 'sans titre'}"]
    if meta.get("chaine"):
        entete.append(f"Chaîne : {meta['chaine']}")
    if meta.get("duree_s"):
        entete.append(f"Durée totale : {timecode(meta['duree_s'])}")
    if nb_blocs > 1:
        entete.append(
            f"Extrait {num_bloc}/{nb_blocs} : phrases #{phrases[0].id} à #{phrases[-1].id} "
            f"({timecode(phrases[0].debut)} → {timecode(phrases[-1].fin)}). "
            "Ne choisis que des phrases de cet extrait."
        )
    corps = "\n".join(formater_ligne(p) for p in phrases)
    return "\n".join(entete) + f"\n\n<transcription>\n{corps}\n</transcription>"


def selectionner_bloc(client, modele, systeme, message, max_tokens, usages: list):
    """Un appel à Claude, avec une seule relance si la réponse est inexploitable."""
    messages = [{"role": "user", "content": message}]
    for tentative in (1, 2):
        rep = client.messages.create(model=modele, max_tokens=max_tokens, system=systeme, messages=list(messages))
        usages.append(Utilisation(rep.usage.input_tokens, rep.usage.output_tokens))
        texte = "".join(b.text for b in rep.content if getattr(b, "type", "text") == "text")
        try:
            valides, erreurs = parser_reponse(texte)
            for e in erreurs:
                log.warning("Sortie de Claude : %s", e)
            if not valides:
                raise ValueError("aucun candidat valide")
            return valides
        except ValueError as e:
            if tentative == 2:
                raise ValueError(f"Réponse de Claude inexploitable après relance : {e}") from e
            log.warning("Réponse de Claude inexploitable (%s) : relance", e)
            messages += [
                {"role": "assistant", "content": texte},
                {"role": "user", "content": f"Ta réponse est inexploitable ({e}). "
                                            "Renvoie uniquement l'objet JSON demandé, sans rien d'autre."},
            ]


def selectionner(phrases: list, meta: dict, cfg: dict, client, usages: list) -> list:
    """Pipeline de sélection complet sur une transcription ; `usages` est rempli au fil des appels."""
    sel = cfg["selection"]
    par_id = {p.id: p for p in phrases}
    blocs = decouper_blocs(phrases, sel["bloc_max_caracteres"], sel["bloc_recouvrement_caracteres"])
    n = len(blocs)
    min_b = math.ceil(sel["clips_min"] / n)
    max_b = sel["clips_max"] if n == 1 else math.ceil(sel["clips_max"] / n) + 2
    systeme = remplir_prompt(charger_prompt(cfg, "selection"), cfg, min_b, max_b)

    tous = []
    for i, (a, b) in enumerate(blocs, 1):
        log.info("Sélection : bloc %d/%d (phrases %d à %d)", i, n, a, b - 1)
        message = construire_message(meta, phrases[a:b], i, n)
        for brut in selectionner_bloc(client, sel["modele"], systeme, message, sel["max_tokens_sortie"], usages):
            clip = vers_candidat_clip(brut, par_id, range(a, b))
            if clip:
                tous.append(clip)
    finaux = dedoublonner(tous, sel["chevauchement_max"], sel["clips_max"])
    if not finaux:
        raise ValueError("Aucun candidat exploitable")
    if len(finaux) < sel["clips_min"]:
        log.warning("Seulement %d candidats (minimum souhaité : %d)", len(finaux), sel["clips_min"])
    return finaux


def selectionner_video(conn, cfg: dict, video_id: str, client=None):
    """Étape « selection » d'une vidéo : lit la transcription en cache, enregistre les candidats."""
    ligne = conn.execute("SELECT chemin_json FROM transcripts WHERE video_id=?", (video_id,)).fetchone()
    if not ligne:
        raise RuntimeError("Transcription introuvable : lancez d'abord l'étape de transcription")
    v = db.video(conn, video_id)
    donnees = json.loads(Path(ligne["chemin_json"]).read_text(encoding="utf-8"))
    phrases = decouper_phrases(mots_depuis_deepgram(donnees), cfg["transcription"]["phrase_max_mots"])
    client = client or creer_client()
    usages: list = []
    try:
        clips = selectionner(phrases, {"titre": v["titre"], "chaine": v["chaine"], "duree_s": v["duree_s"]},
                             cfg, client, usages)
    finally:
        # l'argent est dépensé même si la sélection échoue : on le compte dans tous les cas
        modele = cfg["selection"]["modele"]
        for u in usages:
            db.enregistrer_cout(conn, video_id, "selection", "anthropic", modele, u.entree, u.sortie,
                                cout_claude(cfg, modele, u.entree, u.sortie))
    with conn:  # tout ou rien : pas de demi-liste de candidats en base
        conn.execute("DELETE FROM clips WHERE video_id=? AND statut='candidat'", (video_id,))
        for c in clips:
            conn.execute(
                "INSERT OR IGNORE INTO clips (video_id, debut_s, fin_s, phrase_debut, phrase_fin, sujet, note, raison, cree_le)"
                " VALUES (?,?,?,?,?,?,?,?,?)",
                (video_id, c.debut_s, c.fin_s, c.phrase_debut, c.phrase_fin, c.sujet, c.note, c.raison, db.maintenant()),
            )
    log.info("Sélection terminée : %d candidats", len(clips))
