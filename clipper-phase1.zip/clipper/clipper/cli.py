"""Ligne de commande : add, run, review, publish, status, stats."""
import argparse
import logging
import sys

from . import config, db, ingest, runner
from .transcript import timecode

log = logging.getLogger("clipper")
SYMBOLES = {"ok": "✔", "a_faire": "·", "echec": "✘"}


def configurer_logs(cfg):
    fichier = config.dossier(cfg, "logs") / "clipper.log"
    fmt = logging.Formatter("%(asctime)s %(levelname)-8s %(message)s", "%H:%M:%S")
    log.setLevel(logging.DEBUG)
    for h in (logging.StreamHandler(sys.stderr), logging.FileHandler(fichier, encoding="utf-8")):
        h.setFormatter(fmt)
        h.setLevel(logging.INFO if isinstance(h, logging.StreamHandler) else logging.DEBUG)
        log.addHandler(h)


def cmd_add(args, cfg, conn):
    bilan = ingest.ajouter_url(conn, cfg, args.url)
    print(f"{bilan['nouvelles']} nouvelle(s) vidéo(s), {bilan['connues']} déjà connue(s), "
          f"{bilan['ignorees']} ignorée(s) (trop courtes).")
    if bilan["nouvelles"]:
        print("Étape suivante : clipper run")
    return 0


def cmd_run(args, cfg, conn):
    bilan = runner.lancer(conn, cfg, args.video, args.limite)
    print(f"Terminé : {bilan['ok']} vidéo(s) traitée(s), {bilan['echec']} en échec.")
    if bilan["echec"]:
        print("Détails : clipper status — les vidéos en échec seront réessayées au prochain run.")
    return 1 if bilan["echec"] else 0


def cmd_status(args, cfg, conn):
    if args.video_id:
        return _detail_video(conn, args.video_id, cfg)
    lignes = conn.execute(
        "SELECT v.*, (SELECT COUNT(*) FROM clips c WHERE c.video_id=v.video_id) AS nb_clips,"
        " (SELECT COALESCE(SUM(cout_usd),0) FROM cout_api a WHERE a.video_id=v.video_id) AS cout"
        " FROM videos v ORDER BY cree_le").fetchall()
    if not lignes:
        print("Aucune vidéo. Commencez par : clipper add URL")
        return 0
    print(f"{'ID':<13}{'Titre':<34}{'Durée':>8}  Ing Tra Sél  {'Clips':>5}  {'Coût':>8}")
    for v in lignes:
        titre = (v["titre"] or "?")[:32]
        duree = timecode(v["duree_s"]) if v["duree_s"] else "?"
        etapes = "   ".join(SYMBOLES[v[e]] for e in ("ingestion", "transcription", "selection"))
        print(f"{v['video_id']:<13}{titre:<34}{duree:>8}  {etapes}  {v['nb_clips']:>5}  {v['cout']:>7.3f}$")
        if v["erreur"]:
            print(f"{'':<13}↳ {v['erreur'][:100]}")
    total = conn.execute("SELECT COALESCE(SUM(cout_usd),0) FROM cout_api").fetchone()[0]
    print(f"\nCoût estimé cumulé : {total:.3f} USD (tarifs de config.yaml, à vérifier)")
    return 0


def _detail_video(conn, video_id, cfg):
    v = db.video(conn, video_id)
    if not v:
        print(f"Vidéo inconnue : {video_id}")
        return 1
    print(f"{v['titre']}\n{v['url']}\n")
    clips = conn.execute("SELECT * FROM clips WHERE video_id=? ORDER BY debut_s", (video_id,)).fetchall()
    if not clips:
        print("Aucun candidat pour l'instant.")
    dmin, dmax = cfg["selection"]["duree_min_s"], cfg["selection"]["duree_max_s"]
    for c in clips:
        duree = c["fin_s"] - c["debut_s"]
        alerte = "" if dmin <= duree <= dmax else "  ⚠ durée hors plage (sera rejeté en phase 2)"
        print(f"[{c['id']}] note {c['note']:>3}  {timecode(c['debut_s'])} → {timecode(c['fin_s'])} "
              f"({int(duree // 60)}:{int(duree % 60):02d}){alerte}")
        print(f"     {c['sujet']}\n     ↳ {c['raison']}\n")
    cout = conn.execute("SELECT COALESCE(SUM(cout_usd),0) FROM cout_api WHERE video_id=?", (video_id,)).fetchone()[0]
    print(f"Coût estimé de cette vidéo : {cout:.3f} USD")
    return 0


def _bientot(phase):
    def commande(args, cfg, conn):
        print(f"Cette commande arrive en phase {phase}.")
        return 2
    return commande


def construire_parseur():
    p = argparse.ArgumentParser(prog="clipper", description="Vidéos YouTube longues → clips publiés.")
    sub = p.add_subparsers(dest="commande", required=True)
    a = sub.add_parser("add", help="Ajouter une vidéo, une playlist ou une chaîne")
    a.add_argument("url")
    a.set_defaults(fonction=cmd_add)
    r = sub.add_parser("run", help="Traiter les vidéos en attente (reprend après un crash)")
    r.add_argument("--video", help="ne traiter que cet identifiant de vidéo")
    r.add_argument("--limite", type=int, help="nombre maximum de vidéos à traiter")
    r.set_defaults(fonction=cmd_run)
    s = sub.add_parser("status", help="État, coûts ; avec un identifiant : liste des candidats")
    s.add_argument("video_id", nargs="?")
    s.set_defaults(fonction=cmd_status)
    for nom, phase, aide in (("review", 2, "Ouvrir l'interface de revue"),
                             ("publish", 3, "Publier la file des clips validés"),
                             ("stats", 4, "Relever les statistiques des clips publiés")):
        sub.add_parser(nom, help=aide).set_defaults(fonction=_bientot(phase))
    return p


def main(argv=None):
    args = construire_parseur().parse_args(argv)
    try:
        cfg = config.charger()
        configurer_logs(cfg)
        conn = db.connecter(config.dossier(cfg, "donnees") / "clipper.db")
        return args.fonction(args, cfg, conn)
    except config.ErreurConfig as e:
        print(f"Erreur de configuration : {e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nInterrompu. Relancez la même commande : le travail déjà fait est conservé.", file=sys.stderr)
        return 130
