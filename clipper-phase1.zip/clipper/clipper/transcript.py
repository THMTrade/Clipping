"""Format interne de la transcription : mots horodatés → phrases numérotées.

Les phrases sont la base de tout le pipeline : Claude choisit des numéros de phrases,
ce qui garantit que début et fin tombent sur une frontière de phrase.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class Mot:
    texte: str
    debut: float
    fin: float
    locuteur: int = 0


@dataclass(frozen=True)
class Phrase:
    id: int
    debut: float
    fin: float
    locuteur: int
    texte: str


def mots_depuis_deepgram(donnees: dict) -> list:
    """Extrait les mots (avec ponctuation et locuteur) d'une réponse Deepgram brute."""
    try:
        alt = donnees["results"]["channels"][0]["alternatives"][0]
        bruts = alt["words"]
    except (KeyError, IndexError, TypeError) as e:
        raise ValueError("Réponse Deepgram inattendue : aucun mot trouvé") from e
    mots = [
        Mot(
            texte=w.get("punctuated_word") or w["word"],
            debut=float(w["start"]),
            fin=float(w["end"]),
            locuteur=int(w.get("speaker", 0)),
        )
        for w in bruts
    ]
    if not mots:
        raise ValueError("Transcription vide : la vidéo contient-elle de la parole ?")
    return mots


def _fin_de_phrase(texte: str) -> bool:
    return texte.rstrip("\"'»”)").endswith((".", "?", "!", "…"))


def decouper_phrases(mots: list, max_mots: int = 80) -> list:
    """Coupe sur la ponctuation forte, au changement de locuteur, ou après max_mots mots."""
    phrases, courant = [], []

    def vider():
        if courant:
            phrases.append(Phrase(
                id=len(phrases),
                debut=courant[0].debut,
                fin=courant[-1].fin,
                locuteur=courant[0].locuteur,
                texte=" ".join(m.texte for m in courant),
            ))
            courant.clear()

    for mot in mots:
        if courant and mot.locuteur != courant[-1].locuteur:
            vider()
        courant.append(mot)
        if _fin_de_phrase(mot.texte) or len(courant) >= max_mots:
            vider()
    vider()
    return phrases


def timecode(secondes: float) -> str:
    s = int(secondes)
    return f"{s // 3600}:{s % 3600 // 60:02d}:{s % 60:02d}"


def formater_ligne(p: Phrase) -> str:
    """Ligne envoyée à Claude : `#12 [0:03:21] L1: texte`."""
    return f"#{p.id} [{timecode(p.debut)}] L{p.locuteur}: {p.texte}"
