"""État du projet dans SQLite. Chaque étape d'une vidéo a un statut : a_faire / ok / echec."""
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS videos (
  video_id TEXT PRIMARY KEY,
  url TEXT NOT NULL,
  titre TEXT, chaine TEXT, duree_s REAL, resolution TEXT, date_publication TEXT,
  chemin_video TEXT, meta_json TEXT,
  ingestion TEXT NOT NULL DEFAULT 'a_faire',
  transcription TEXT NOT NULL DEFAULT 'a_faire',
  selection TEXT NOT NULL DEFAULT 'a_faire',
  erreur TEXT,
  cree_le TEXT NOT NULL, maj_le TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS transcripts (
  video_id TEXT PRIMARY KEY REFERENCES videos(video_id),
  chemin_json TEXT NOT NULL, moteur TEXT, langue TEXT,
  nb_mots INTEGER, nb_locuteurs INTEGER, cree_le TEXT
);
CREATE TABLE IF NOT EXISTS clips (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  video_id TEXT NOT NULL REFERENCES videos(video_id),
  debut_s REAL NOT NULL, fin_s REAL NOT NULL,
  phrase_debut INTEGER, phrase_fin INTEGER,
  sujet TEXT, note INTEGER, raison TEXT,
  statut TEXT NOT NULL DEFAULT 'candidat',
  cree_le TEXT,
  UNIQUE (video_id, phrase_debut, phrase_fin)
);
CREATE TABLE IF NOT EXISTS cout_api (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  video_id TEXT, etape TEXT, service TEXT, modele TEXT,
  quantite_entree REAL, quantite_sortie REAL, cout_usd REAL, cree_le TEXT
);
"""
# Les tables des phases suivantes (miniatures, publications, stats) seront ajoutées ici.


def maintenant() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connecter(chemin) -> sqlite3.Connection:
    chemin = Path(chemin)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(chemin)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript(SCHEMA)
    conn.commit()
    return conn


def ajouter_video(conn, video_id, url, titre=None, duree_s=None) -> bool:
    """Ajoute une vidéo ; renvoie False si elle existe déjà (idempotent)."""
    ts = maintenant()
    cur = conn.execute(
        "INSERT OR IGNORE INTO videos (video_id, url, titre, duree_s, cree_le, maj_le) VALUES (?,?,?,?,?,?)",
        (video_id, url, titre, duree_s, ts, ts),
    )
    conn.commit()
    return cur.rowcount == 1


def maj_video(conn, video_id, **champs):
    colonnes = ", ".join(f"{c}=?" for c in champs)
    conn.execute(
        f"UPDATE videos SET {colonnes}, maj_le=? WHERE video_id=?",
        (*champs.values(), maintenant(), video_id),
    )
    conn.commit()


def video(conn, video_id):
    return conn.execute("SELECT * FROM videos WHERE video_id=?", (video_id,)).fetchone()


def enregistrer_cout(conn, video_id, etape, service, modele, q_entree, q_sortie, cout_usd):
    conn.execute(
        "INSERT INTO cout_api (video_id, etape, service, modele, quantite_entree, quantite_sortie, cout_usd, cree_le)"
        " VALUES (?,?,?,?,?,?,?,?)",
        (video_id, etape, service, modele, q_entree, q_sortie, cout_usd, maintenant()),
    )
    conn.commit()
