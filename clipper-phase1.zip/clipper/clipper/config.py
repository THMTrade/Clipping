"""Chargement de config.yaml et du fichier .env."""
import os
from pathlib import Path

import yaml

RACINE = Path(__file__).resolve().parent.parent


class ErreurConfig(Exception):
    """Réglage ou clé manquante."""


def charger_env(chemin=None):
    """Lit .env (CLE=valeur) sans écraser les variables déjà définies."""
    chemin = Path(chemin) if chemin else RACINE / ".env"
    if not chemin.exists():
        return
    for ligne in chemin.read_text(encoding="utf-8").splitlines():
        ligne = ligne.strip()
        if not ligne or ligne.startswith("#") or "=" not in ligne:
            continue
        cle, valeur = ligne.split("=", 1)
        os.environ.setdefault(cle.strip(), valeur.strip().strip('"').strip("'"))


def charger(chemin=None) -> dict:
    charger_env()
    chemin = Path(chemin) if chemin else RACINE / "config.yaml"
    if not chemin.exists():
        raise ErreurConfig(f"Fichier de configuration introuvable : {chemin}")
    return yaml.safe_load(chemin.read_text(encoding="utf-8")) or {}


def dossier(cfg: dict, nom: str, sous_dossier: str = "") -> Path:
    """Dossier configuré (créé au besoin), ex. dossier(cfg, 'donnees', 'videos')."""
    p = Path(cfg["dossiers"][nom])
    p = p if p.is_absolute() else RACINE / p
    p = p / sous_dossier if sous_dossier else p
    p.mkdir(parents=True, exist_ok=True)
    return p


def cle_api(nom: str) -> str:
    valeur = os.environ.get(nom, "").strip()
    if not valeur:
        raise ErreurConfig(f"Clé {nom} absente : renseignez-la dans .env (voir .env.example).")
    return valeur
