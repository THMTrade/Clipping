"""Clipper : vidéos longues → clips YouTube."""
__version__ = "0.1.0"
