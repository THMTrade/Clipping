"""Orchestration : chaque vidéo passe par ses étapes ; un échec n'arrête que cette vidéo."""
import logging

from . import db, ingest, select, transcribe

log = logging.getLogger("clipper")

# (colonne de statut, fonction). Une étape déjà « ok » n'est jamais refaite.
ETAPES = [
    ("ingestion", ingest.telecharger),
    ("transcription", transcribe.transcrire),
    ("selection", select.selectionner_video),
]


def traiter_video(conn, cfg, video_id) -> bool:
    for nom, fonction in ETAPES:
        if db.video(conn, video_id)[nom] == "ok":
            continue
        try:
            fonction(conn, cfg, video_id)
        except Exception as e:  # noqa: BLE001 : on isole l'échec de cette vidéo, le message est conservé
            log.error("Échec de l'étape « %s » pour %s : %s", nom, video_id, e)
            log.debug("Détail", exc_info=True)
            db.maj_video(conn, video_id, **{nom: "echec"}, erreur=f"{nom} : {e}")
            return False
        db.maj_video(conn, video_id, **{nom: "ok"}, erreur=None)
    return True


def lancer(conn, cfg, video_id=None, limite=None) -> dict:
    """Traite les vidéos dont une étape reste à faire (ou en échec : elles sont réessayées)."""
    requete = "SELECT video_id, titre FROM videos WHERE (ingestion!='ok' OR transcription!='ok' OR selection!='ok')"
    params = []
    if video_id:
        requete += " AND video_id=?"
        params.append(video_id)
    requete += " ORDER BY cree_le"
    a_traiter = conn.execute(requete, params).fetchall()
    if limite:
        a_traiter = a_traiter[:limite]
    bilan = {"ok": 0, "echec": 0}
    for i, v in enumerate(a_traiter, 1):
        log.info("── Vidéo %d/%d : %s (%s)", i, len(a_traiter), v["titre"] or "?", v["video_id"])
        bilan["ok" if traiter_video(conn, cfg, v["video_id"]) else "echec"] += 1
    return bilan
