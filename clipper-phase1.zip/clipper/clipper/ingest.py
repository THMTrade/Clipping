"""Ingestion : résolution des URL (vidéo, playlist, chaîne) et téléchargement via yt-dlp."""
import json
import logging
import re

from . import config, db

log = logging.getLogger("clipper")

_CHAINE = re.compile(r"youtube\.com/(@[^/?]+|channel/[^/?]+|c/[^/?]+|user/[^/?]+)$")


def normaliser_url(url: str) -> str:
    """Une URL de chaîne nue pointe vers ses onglets : on vise l'onglet Vidéos (pas les Shorts ni les directs)."""
    u = url.strip().split("?")[0].rstrip("/")
    return u + "/videos" if _CHAINE.search(u) else url.strip()


def _aplatir(info: dict):
    """Parcourt récursivement playlists et onglets de chaîne ; produit les vidéos."""
    for entree in info.get("entries") or []:
        if not entree:
            continue
        if entree.get("_type") == "playlist" or entree.get("entries"):
            yield from _aplatir(entree)
        elif entree.get("id"):
            yield entree


def resoudre_url(url: str) -> list:
    """Renvoie [{id, titre, duree_s}] pour une URL de vidéo, de playlist ou de chaîne."""
    from yt_dlp import YoutubeDL  # import tardif : inutile pour les tests
    opts = {"quiet": True, "no_warnings": True, "extract_flat": "in_playlist", "skip_download": True}
    with YoutubeDL(opts) as ydl:
        info = ydl.extract_info(normaliser_url(url), download=False)
    if not info:
        raise RuntimeError(f"Impossible de lire l'URL : {url}")
    entrees = _aplatir(info) if info.get("entries") else [info]
    vus, resultat = set(), []
    for e in entrees:
        if e["id"] in vus:
            continue
        vus.add(e["id"])
        resultat.append({"id": e["id"], "titre": e.get("title"), "duree_s": e.get("duration")})
    return resultat


def ajouter_url(conn, cfg: dict, url: str, resolveur=resoudre_url) -> dict:
    """Enregistre les vidéos de l'URL sans rien télécharger. Idempotent : les doublons sont comptés, pas réinsérés."""
    duree_min = cfg["ingestion"].get("duree_min_s", 0)
    bilan = {"nouvelles": 0, "connues": 0, "ignorees": 0}
    for v in resolveur(url):
        if v["duree_s"] is not None and v["duree_s"] < duree_min:
            log.info("Ignorée (trop courte, %d s) : %s", v["duree_s"], v["titre"])
            bilan["ignorees"] += 1
        elif db.ajouter_video(conn, v["id"], f"https://www.youtube.com/watch?v={v['id']}", v["titre"], v["duree_s"]):
            bilan["nouvelles"] += 1
        else:
            bilan["connues"] += 1
    return bilan


def telecharger(conn, cfg: dict, video_id: str):
    """Télécharge la vidéo (meilleure qualité configurée) et stocke ses métadonnées."""
    from yt_dlp import YoutubeDL
    v = db.video(conn, video_id)
    dossier = config.dossier(cfg, "donnees", "videos")
    opts = {
        "format": cfg["ingestion"]["format"],
        "merge_output_format": cfg["ingestion"]["conteneur"],
        "outtmpl": str(dossier / "%(id)s.%(ext)s"),
        "quiet": True, "no_warnings": True, "noprogress": True,
        "retries": 5, "fragment_retries": 5, "continuedl": True,  # reprise après coupure
    }
    log.info("Téléchargement : %s", v["titre"] or video_id)
    with YoutubeDL(opts) as ydl:
        info = ydl.extract_info(v["url"], download=True)
    chemin = info["requested_downloads"][0]["filepath"]
    garder = ("id", "title", "uploader", "channel", "channel_id", "duration", "upload_date",
              "width", "height", "webpage_url", "description", "tags", "chapters")
    db.maj_video(
        conn, video_id,
        titre=info.get("title"), chaine=info.get("channel") or info.get("uploader"),
        duree_s=info.get("duration"), resolution=f"{info.get('width')}x{info.get('height')}",
        date_publication=info.get("upload_date"), chemin_video=str(chemin),
        meta_json=json.dumps({k: info.get(k) for k in garder}, ensure_ascii=False),
    )
