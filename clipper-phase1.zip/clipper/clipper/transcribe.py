"""Transcription horodatée au mot avec locuteurs (Deepgram), mise en cache : jamais deux fois."""
import json
import logging
import shutil
import subprocess
import time
from pathlib import Path

from . import config, db
from .transcript import mots_depuis_deepgram

log = logging.getLogger("clipper")


def extraire_audio(video: Path, sortie: Path):
    """Piste audio mono 16 kHz légère : on n'envoie pas la vidéo entière à l'API."""
    if shutil.which("ffmpeg") is None:
        raise RuntimeError("ffmpeg introuvable : installez-le (voir README).")
    tmp = sortie.with_suffix(".part.mp3")
    subprocess.run(
        ["ffmpeg", "-y", "-loglevel", "error", "-i", str(video), "-vn", "-ac", "1", "-ar", "16000",
         "-b:a", "48k", "-f", "mp3", str(tmp)],
        check=True,
    )
    tmp.replace(sortie)


def _morceaux(chemin: Path, taille=1 << 20):
    with chemin.open("rb") as f:
        while bloc := f.read(taille):
            yield bloc


def appeler_deepgram(audio: Path, cfg_t: dict, cle: str) -> dict:
    import httpx  # import tardif : inutile pour les tests
    params = {"model": cfg_t["modele"], "language": cfg_t["langue"], "diarize": "true",
              "punctuate": "true", "smart_format": "true"}
    entetes = {"Authorization": f"Token {cle}", "Content-Type": "audio/mpeg"}
    derniere = None
    for tentative in (1, 2, 3):
        try:
            r = httpx.post("https://api.deepgram.com/v1/listen", params=params, headers=entetes,
                           content=_morceaux(audio), timeout=httpx.Timeout(1800.0, connect=30.0))
            if r.status_code < 500 and r.status_code != 429:
                r.raise_for_status()  # 4xx : clé ou requête invalide, inutile de réessayer
                return r.json()
            derniere = f"HTTP {r.status_code}"
        except httpx.TransportError as e:
            derniere = str(e)
        log.warning("Deepgram : échec (%s), tentative %d/3", derniere, tentative)
        time.sleep(5 * tentative)
    raise RuntimeError(f"Deepgram injoignable après 3 tentatives : {derniere}")


def transcrire(conn, cfg: dict, video_id: str):
    cfg_t = cfg["transcription"]
    if cfg_t["moteur"] != "deepgram":
        raise NotImplementedError("Seul le moteur « deepgram » est implémenté pour l'instant.")
    v = db.video(conn, video_id)
    cache = config.dossier(cfg, "donnees", "transcripts") / f"{video_id}.deepgram.json"

    if cache.exists():
        log.info("Transcription déjà en cache : aucun appel API")
    else:
        if not v["chemin_video"] or not Path(v["chemin_video"]).exists():
            raise RuntimeError("Fichier vidéo introuvable : relancez l'ingestion")
        audio = config.dossier(cfg, "donnees", "audio") / f"{video_id}.mp3"
        if not audio.exists():
            log.info("Extraction de l'audio")
            extraire_audio(Path(v["chemin_video"]), audio)
        log.info("Transcription Deepgram (%s, %s)", cfg_t["modele"], cfg_t["langue"])
        donnees = appeler_deepgram(audio, cfg_t, config.cle_api("DEEPGRAM_API_KEY"))
        duree = donnees.get("metadata", {}).get("duration") or v["duree_s"] or 0
        # écriture atomique : un crash ne laisse jamais un cache à moitié écrit
        tmp = cache.with_suffix(".part")
        tmp.write_text(json.dumps(donnees, ensure_ascii=False), encoding="utf-8")
        tmp.replace(cache)
        db.enregistrer_cout(conn, video_id, "transcription", "deepgram", cfg_t["modele"], duree / 60, 0,
                            duree / 60 * cfg["tarifs"]["deepgram_usd_par_minute"])
        audio.unlink(missing_ok=True)

    mots = mots_depuis_deepgram(json.loads(cache.read_text(encoding="utf-8")))
    conn.execute(
        "INSERT OR REPLACE INTO transcripts (video_id, chemin_json, moteur, langue, nb_mots, nb_locuteurs, cree_le)"
        " VALUES (?,?,?,?,?,?,?)",
        (video_id, str(cache), "deepgram", cfg_t["langue"], len(mots), len({m.locuteur for m in mots}), db.maintenant()),
    )
    conn.commit()
    log.info("Transcription prête : %d mots, %d locuteur(s)", len(mots), len({m.locuteur for m in mots}))
