# Clipper

Transforme des vidéos YouTube longues en clips de 2 à 5 minutes, à valider puis publier. Phase 1 disponible : ingestion, transcription, sélection des candidats.

## Installation

1. **Prérequis** : Python 3.10+, `ffmpeg` (`sudo apt install ffmpeg` / `brew install ffmpeg` / `winget install ffmpeg`).
2. **Environnement** :
   ```
   python -m venv .venv
   source .venv/bin/activate        # Windows : .venv\Scripts\activate
   pip install -e ".[dev]"
   ```
3. **Clés API** : `cp .env.example .env`, puis renseignez
   - `ANTHROPIC_API_KEY` (console.anthropic.com)
   - `DEEPGRAM_API_KEY` (console.deepgram.com)
4. **Réglages** : relisez `config.yaml` (commenté). Vérifiez les tarifs de la section `tarifs`, sinon les coûts affichés seront faux.
5. **Test** : `pytest` (aucun appel réseau, rien à payer).

## Utilisation (phase 1)

```
clipper add "https://www.youtube.com/watch?v=XXXX"   # ou playlist, ou chaîne
clipper run --limite 1                               # une vidéo pour commencer
clipper status                                       # états et coûts
clipper status XXXX                                  # candidats : note, timecodes, sujet, raison
```

Si quelque chose échoue, relancez la même commande : ce qui est fait (téléchargement, transcription payée) n'est jamais refait. Logs détaillés dans `logs/clipper.log`.

Les consignes de sélection sont dans `prompts/selection.md` : modifiez-les sans toucher au code, puis supprimez les candidats d'une vidéo avec `sqlite3 data/clipper.db "UPDATE videos SET selection='a_faire' WHERE video_id='XXXX'"` et relancez `clipper run`.

## À venir
Phases 2 à 4 : découpe, miniatures, revue web, publication (avec la procédure OAuth YouTube pas à pas et l'audit de l'API), suivi.
